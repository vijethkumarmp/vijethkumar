import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { ProjectGrid } from './components/ProjectGrid';
import { CaseStudyModal } from './components/CaseStudyModal';
import { SkillsSection } from './components/SkillsSection';
import { EducationSection } from './components/EducationSection';
import { ContactSection } from './components/ContactSection';
import { ResumeModal } from './components/ResumeModal';
import { Footer } from './components/Footer';

export default function App() {
  const [isResumeModalOpen, setIsResumeModalOpen] = useState(false);
  const [activeCaseStudyId, setActiveCaseStudyId] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 font-sans selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Sticky Header Navigation */}
      <Navbar
        onOpenResume={() => setIsResumeModalOpen(true)}
      />

      {/* Main Content Sections */}
      <main>
        {/* Hero Section with Interactive Background & Stat Badges */}
        <Hero
          onOpenResume={() => setIsResumeModalOpen(true)}
        />

        {/* Engineer Profile & Narrative Bio */}
        <AboutSection />

        {/* Filterable Complete Project Portfolio Grid */}
        <ProjectGrid
          onOpenCaseStudy={(id) => setActiveCaseStudyId(id)}
        />

        {/* Grouped Skills & Technical Stack */}
        <SkillsSection />

        {/* Academic Journey Timeline */}
        <EducationSection />

        {/* Direct Contact & Resume Download Section */}
        <ContactSection
          onOpenResume={() => setIsResumeModalOpen(true)}
        />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals & Overlays */}
      {/* 1. Case Study Modal */}
      <CaseStudyModal
        projectId={activeCaseStudyId}
        onClose={() => setActiveCaseStudyId(null)}
      />

      {/* 2. Résumé Modal */}
      <ResumeModal
        isOpen={isResumeModalOpen}
        onClose={() => setIsResumeModalOpen(false)}
      />
    </div>
  );
}
