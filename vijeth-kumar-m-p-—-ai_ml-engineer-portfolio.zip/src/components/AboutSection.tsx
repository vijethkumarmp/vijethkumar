import React from 'react';
import { User, Cpu, ShieldCheck, Code2, Globe2, BookOpen, Sparkles, CheckCircle2 } from 'lucide-react';
import { PERSONAL_INFO, LANGUAGES } from '../data/portfolioData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 border-b border-slate-800/60 relative bg-[#0a0f1c]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/50 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-semibold mb-3">
            <User className="w-3.5 h-3.5" />
            <span>ENGINEER PROFILE & PHILOSOPHY</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-white tracking-tight">
            About Vijeth Kumar M P
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Main Narrative - Left 7 Cols */}
          <div className="lg:col-span-7 space-y-6 text-slate-300 font-sans leading-relaxed">
            <p className="text-base sm:text-lg text-slate-200">
              I am a final-year Artificial Intelligence & Data Science engineering student at Don Bosco Institute of Technology (VTU, Bengaluru) who builds full-stack agentic AI platforms from the ground up.
            </p>

            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="font-heading font-semibold text-lg text-emerald-400 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                Core Engineering Philosophy
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                {PERSONAL_INFO.positioning}
              </p>
            </div>

            <div className="space-y-3 pt-2">
              <h4 className="font-heading text-sm uppercase tracking-wider text-slate-400 font-mono">
                Key Differentiators in My Work:
              </h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-white">Beyond Jupyter Notebooks:</strong> Every AI system I construct includes deployable React UIs, API endpoints, error handling, and persistent databases.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-white">Framework-Free Rigor:</strong> In addition to using LangGraph and LangChain, I re-architect agent loops in pure Python to eliminate reliance on library black-boxes.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-white">Zero-Cost Resource Efficiency:</strong> Architectures are engineered to execute on cloud free-tiers (Firebase, ChromaDB, Vercel/Cloud Run) for zero-barrier reproducibility.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-white">Exhaustive System Documentation:</strong> Documented with rigorous technical reports (e.g. 83-page EquityMind AI architecture report and live project logs).
                  </span>
                </li>
              </ul>
            </div>
          </div>

          {/* Right 5 Cols: Quick Identity & Languages */}
          <div className="lg:col-span-5 space-y-6">
            {/* Identity Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="font-heading font-semibold text-white text-base flex items-center justify-between pb-3 border-b border-slate-800">
                <span>Quick Overview</span>
                <span className="font-mono text-xs text-emerald-400">BE AI & DS (2023–2027)</span>
              </h3>

              <div className="space-y-3 font-mono text-xs text-slate-300">
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-500">Name:</span>
                  <span className="text-white font-medium">Vijeth Kumar M P</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-500">Location:</span>
                  <span className="text-slate-200">Bengaluru, Karnataka, India</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-500">Institution:</span>
                  <span className="text-slate-200 text-right">Don Bosco Institute of Technology</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-500">Academic Score:</span>
                  <span className="text-emerald-400 font-bold">CGPA 7.0 / 10.0 (Final Year)</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-500">Email:</span>
                  <a href={`mailto:${PERSONAL_INFO.email}`} className="text-emerald-400 hover:underline">
                    {PERSONAL_INFO.email}
                  </a>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">Phone:</span>
                  <span className="text-slate-200">{PERSONAL_INFO.phone}</span>
                </div>
              </div>
            </div>

            {/* Languages Spoken Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-3">
              <h3 className="font-heading font-semibold text-white text-sm flex items-center gap-2">
                <Globe2 className="w-4 h-4 text-cyan-400" />
                Linguistic Capabilities
              </h3>
              <p className="text-xs text-slate-400">
                Multilingual communication for collaborative global & regional engineering teams:
              </p>

              <div className="flex flex-wrap gap-2 pt-1">
                {LANGUAGES.map((lang, idx) => (
                  <div
                    key={idx}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-mono flex items-center gap-2 ${
                      lang.proficiency === 'Fluent'
                        ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                        : 'bg-slate-800/60 border-slate-700/60 text-slate-400'
                    }`}
                  >
                    <span className="font-medium text-white">{lang.name}</span>
                    {lang.nativeName && <span className="text-[10px] text-slate-400">({lang.nativeName})</span>}
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded ${
                        lang.proficiency === 'Fluent'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-slate-700/50 text-slate-400'
                      }`}
                    >
                      {lang.proficiency}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
