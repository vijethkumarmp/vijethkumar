import React, { useState } from 'react';
import { X, CheckCircle2, FileText, Cpu, Layers, Bot, Database, Sparkles, ExternalLink, ShieldCheck, ArrowRight, Activity } from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';

interface CaseStudyModalProps {
  projectId: string | null;
  onClose: () => void;
}

export const CaseStudyModal: React.FC<CaseStudyModalProps> = ({ projectId, onClose }) => {
  if (!projectId) return null;

  const project = PROJECTS.find((p) => p.id === projectId);
  if (!project) return null;

  const [activeTab, setActiveTab] = useState<'overview' | 'architecture' | 'decisions' | 'artifacts'>('overview');
  const [artifactView, setArtifactView] = useState<'dashboard' | 'landing'>('dashboard');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-4xl bg-[#0d1322] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-800 flex items-start justify-between bg-slate-900/90">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                {project.domain}
              </span>
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300">
                {project.stackType}
              </span>
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-emerald-400 border border-emerald-500/30">
                {project.status}
              </span>
            </div>
            <h2 className="text-2xl font-heading font-bold text-white">{project.title}</h2>
            <p className="text-xs font-mono text-slate-400">{project.subtitle}</p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800/60 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close Case Study"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Nav Tabs */}
        <div className="px-6 py-3 border-b border-slate-800 bg-slate-950/60 flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-1.5 rounded-lg text-xs font-mono transition-colors cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Overview & Problem
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-4 py-1.5 rounded-lg text-xs font-mono transition-colors cursor-pointer ${
              activeTab === 'architecture'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Architecture Breakdown
          </button>
          <button
            onClick={() => setActiveTab('decisions')}
            className={`px-4 py-1.5 rounded-lg text-xs font-mono transition-colors cursor-pointer ${
              activeTab === 'decisions'
                ? 'bg-emerald-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Key Decisions & Metrics
          </button>
          {project.hasDualArtifacts && (
            <button
              onClick={() => setActiveTab('artifacts')}
              className={`px-4 py-1.5 rounded-lg text-xs font-mono transition-colors cursor-pointer ${
                activeTab === 'artifacts'
                  ? 'bg-purple-500 text-slate-950 font-bold'
                  : 'text-purple-400 hover:text-white hover:bg-purple-950/60'
              }`}
            >
              Dual Visual Artifacts
            </button>
          )}
        </div>

        {/* Modal Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-300 font-sans text-sm flex-1">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-400" />
                  System Description & Tagline
                </h3>
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-200 leading-relaxed">
                  <div className="font-mono text-xs text-emerald-400 mb-2 font-semibold">
                    "{project.tagline}"
                  </div>
                  <p>{project.description}</p>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  Problem Statement
                </h3>
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 leading-relaxed">
                  {project.problem}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'architecture' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  System Architecture
                </h3>
                <p className="text-slate-300 leading-relaxed bg-slate-900/80 p-4 rounded-xl border border-slate-800 font-sans">
                  {project.architecture}
                </p>
              </div>

              {/* 7-Agent Breakdown if EquityMind AI */}
              {project.id === 'equitymind-ai' && project.agents && (
                <div className="space-y-3">
                  <h4 className="font-heading font-bold text-sm text-emerald-400 uppercase tracking-wider font-mono">
                    Specialized Agents in LangGraph Pipeline:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {project.agents.map((ag) => (
                      <div key={ag.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs">
                        <div className="font-bold text-white flex items-center justify-between">
                          <span>{ag.name}</span>
                          <span className="text-[10px] text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded">
                            {ag.model}
                          </span>
                        </div>
                        <div className="text-slate-400 text-[11px] mt-1">{ag.description}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 8-Module Breakdown if GramAmrit */}
              {project.id === 'gramamrit' && (
                <div className="space-y-3">
                  <h4 className="font-heading font-bold text-sm text-cyan-400 uppercase tracking-wider font-mono">
                    8 Rural Civic Governance Modules:
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
                    {[
                      '1. Grievance Redressal',
                      '2. Gram Sabha Notices',
                      '3. Public Asset Tracking',
                      '4. Scheme Eligibility',
                      '5. Revenue Collection',
                      '6. Water & Sanitation',
                      '7. Agriculture Updates',
                      '8. Meeting Minutes'
                    ].map((mod, idx) => (
                      <div key={idx} className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-slate-300 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span>{mod}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tech Stack List */}
              <div>
                <h4 className="font-heading font-bold text-sm text-slate-400 uppercase tracking-wider font-mono mb-2">
                  Complete Tech Stack:
                </h4>
                <div className="flex flex-wrap gap-2">
                  {project.techStackList.map((t) => (
                    <span key={t} className="px-3 py-1 rounded-lg bg-slate-950 text-emerald-400 border border-slate-800 font-mono text-xs">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'decisions' && (
            <div className="space-y-6">
              <div className="space-y-3">
                <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  Key Technical Decisions
                </h3>
                <ul className="space-y-2.5">
                  {project.keyDecisions.map((decision, idx) => (
                    <li key={idx} className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 flex items-start gap-3">
                      <span className="w-5 h-5 rounded-full bg-emerald-950 text-emerald-400 flex items-center justify-center font-mono text-xs font-bold shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className="text-slate-300 leading-relaxed text-sm">{decision}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="font-heading font-bold text-base text-white mb-3">
                  Key Metrics & System Specifications
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {project.metrics.map((m, idx) => (
                    <div key={idx} className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="block text-[10px] font-mono text-slate-400 uppercase">{m.label}</span>
                      <span className="text-base font-heading font-bold text-emerald-400">{m.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'artifacts' && project.hasDualArtifacts && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs font-mono">
                <button
                  onClick={() => setArtifactView('dashboard')}
                  className={`flex-1 py-2 rounded-lg transition-colors cursor-pointer ${
                    artifactView === 'dashboard'
                      ? 'bg-purple-600 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Product Dashboard UI
                </button>
                <button
                  onClick={() => setArtifactView('landing')}
                  className={`flex-1 py-2 rounded-lg transition-colors cursor-pointer ${
                    artifactView === 'landing'
                      ? 'bg-purple-600 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Go-To-Market Landing Page
                </button>
              </div>

              {artifactView === 'dashboard' ? (
                <div className="p-6 bg-slate-950 rounded-2xl border border-purple-500/40 space-y-4 font-mono text-xs">
                  <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                    <span className="text-purple-400 font-bold">TaxNexus Product UI</span>
                    <span className="text-slate-500">Dark Mode Operational Utility</span>
                  </div>
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="block text-slate-400 text-[10px]">Tax RAG Query</span>
                      <span className="text-emerald-400 font-bold">Clause Search</span>
                    </div>
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="block text-slate-400 text-[10px]">Deduction Scanner</span>
                      <span className="text-cyan-400 font-bold">Auto-Identify</span>
                    </div>
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="block text-slate-400 text-[10px]">Compliance Score</span>
                      <span className="text-purple-400 font-bold">98.2% Accurate</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-6 bg-slate-950 rounded-2xl border border-purple-500/40 space-y-4 font-mono text-xs">
                  <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                    <span className="text-purple-400 font-bold">TaxNexus Go-To-Market Landing</span>
                    <span className="text-slate-500">Conversion Oriented UI Design</span>
                  </div>
                  <p className="text-slate-300 font-sans">
                    Independently crafted marketing landing page showcasing high-converting value propositions, pricing tiers, feature breakdowns, and social proof components designed for user acquisition.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between font-mono text-xs">
          <span className="text-slate-400">Architected by Vijeth Kumar M P</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            Close View
          </button>
        </div>
      </div>
    </div>
  );
};
