import React from 'react';
import { EDUCATION_HISTORY } from '../data/portfolioData';
import { GraduationCap, Calendar, MapPin, Award, BookOpen, CheckCircle2 } from 'lucide-react';

export const EducationSection: React.FC = () => {
  return (
    <section id="education" className="py-20 border-b border-slate-800 bg-[#070b14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 font-mono text-xs font-semibold mb-3">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>ACADEMIC TIMELINE & QUALIFICATIONS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-white tracking-tight">
            Education Journey
          </h2>
          <p className="text-slate-400 font-mono text-xs sm:text-sm mt-1">
            Artificial Intelligence & Data Science degree path in Bengaluru.
          </p>
        </div>

        {/* Timeline Layout */}
        <div className="relative pl-6 sm:pl-10 space-y-10 border-l-2 border-slate-800">
          {EDUCATION_HISTORY.map((item, idx) => (
            <div key={item.id} className="relative group">
              {/* Timeline Bullet Node */}
              <div
                className={`absolute -left-[31px] sm:-left-[47px] top-1.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                  item.isCurrent
                    ? 'bg-emerald-500 border-emerald-400 shadow-lg shadow-emerald-500/30'
                    : 'bg-slate-900 border-slate-700'
                }`}
              >
                {item.isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-slate-950 animate-ping" />}
              </div>

              {/* Education Card */}
              <div className="bg-slate-900/80 border border-slate-800 group-hover:border-slate-700 rounded-2xl p-6 backdrop-blur-md space-y-4 transition-all">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-heading font-bold text-lg text-white">
                        {item.institution}
                      </span>
                      {item.isCurrent && (
                        <span className="px-2.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-500/30 font-bold">
                          CURRENT FINAL YEAR
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-mono text-emerald-400 font-semibold">{item.degree}</div>
                  </div>

                  <div className="font-mono text-xs text-slate-400 space-y-1 sm:text-right">
                    <div className="flex items-center sm:justify-end gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      <span>{item.period}</span>
                    </div>
                    <div className="flex items-center sm:justify-end gap-1.5 text-slate-300 font-bold">
                      <Award className="w-3.5 h-3.5 text-amber-400" />
                      <span>{item.score}</span>
                    </div>
                  </div>
                </div>

                {/* Highlights List */}
                <div className="space-y-2">
                  <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                    Key Focus Areas & Academic Milestones:
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {item.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Relevant Coursework Tags if present */}
                {item.coursework && (
                  <div className="pt-2 border-t border-slate-800/80">
                    <span className="text-[11px] font-mono text-slate-400 block mb-2">
                      Core Syllabus & Technical Modules:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {item.coursework.map((course) => (
                        <span
                          key={course}
                          className="px-2.5 py-1 rounded-md bg-slate-950 text-slate-300 border border-slate-800 font-mono text-[10px]"
                        >
                          {course}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
