import React, { useState } from 'react';
import {
  Bot,
  Play,
  CheckCircle2,
  FileText,
  LineChart,
  Cpu,
  Layers,
  Database,
  Terminal,
  TrendingUp,
  AlertTriangle,
  RefreshCw,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Zap,
  Activity
} from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { AgentInfo } from '../types';

interface EquityMindShowcaseProps {
  onOpenReportModal: () => void;
  onOpenCaseStudy: (projectId: string) => void;
}

export const EquityMindShowcase: React.FC<EquityMindShowcaseProps> = ({
  onOpenReportModal,
  onOpenCaseStudy,
}) => {
  const equityProject = PROJECTS.find((p) => p.id === 'equitymind-ai')!;
  const [selectedTicker, setSelectedTicker] = useState('RELIANCE.NS');
  const [isRunning, setIsRunning] = useState(false);
  const [activeStep, setActiveStep] = useState<number>(-1);
  const [activeTab, setActiveTab] = useState<'simulator' | 'orchestration' | 'dashboards'>('simulator');
  const [frameworkMode, setFrameworkMode] = useState<'langgraph' | 'pure-python'>('langgraph');

  const tickerPresets = [
    { symbol: 'RELIANCE.NS', name: 'Reliance Industries', price: '₹2,980.50', change: '+1.8%' },
    { symbol: 'TCS.NS', name: 'Tata Consultancy Services', price: '₹3,840.00', change: '+0.6%' },
    { symbol: 'INFY.NS', name: 'Infosys Limited', price: '₹1,540.20', change: '-0.4%' },
    { symbol: 'TATAMOTORS.NS', name: 'Tata Motors Limited', price: '₹985.40', change: '+3.2%' },
  ];

  const agentSteps = equityProject.agents || [];

  const runSimulator = () => {
    if (isRunning) return;
    setIsRunning(true);
    setActiveStep(0);

    let current = 0;
    const interval = setInterval(() => {
      current++;
      if (current < agentSteps.length) {
        setActiveStep(current);
      } else {
        clearInterval(interval);
        setIsRunning(false);
      }
    }, 900);
  };

  return (
    <section id="equitymind" className="py-20 bg-[#070b14] border-b border-slate-800 relative overflow-hidden">
      {/* Background Subtle Gradient */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-emerald-500/5 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-1/2 h-full bg-cyan-500/5 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header Badge */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 font-mono text-xs font-semibold mb-3">
              <Bot className="w-4 h-4 animate-pulse" />
              <span>PRIMARY showcase FLAGSHIP PROJECT</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-heading font-extrabold text-white tracking-tight">
              EquityMind AI
            </h2>
            <p className="text-slate-400 font-mono text-xs sm:text-sm mt-1">
              Real-time, agentic, RAG-powered equity intelligence for the National Stock Exchange of India (NSE)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenReportModal}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-mono font-semibold text-emerald-400 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 rounded-xl transition-all cursor-pointer shadow-lg shadow-emerald-500/10"
            >
              <FileText className="w-4 h-4" />
              <span>Read 83-Page Report & Diary</span>
            </button>

            <button
              onClick={() => onOpenCaseStudy('equitymind-ai')}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-emerald-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 rounded-xl shadow-md cursor-pointer font-sans"
            >
              <span>Full Case Study</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Lead Grid: Left Narrative & Core Specs | Right Live Interactive Simulator */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-12">
          {/* Left Narrative (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="font-heading text-lg font-bold text-white flex items-center justify-between">
                <span>System Overview</span>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded border border-emerald-500/30">
                  NSE Real-Time
                </span>
              </h3>

              <p className="text-sm text-slate-300 leading-relaxed font-sans">
                EquityMind AI bridges information asymmetry for retail investors by converting raw OHLCV tick data and unstructured market news streams into verifiable BUY / SELL / HOLD consensus signals with confidence bounds.
              </p>

              <div className="space-y-2 pt-2 border-t border-slate-800/80 font-mono text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Agentic Engine:</span>
                  <span className="text-emerald-400 font-medium">LangGraph Multi-Agent Pipeline</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">ML Ensemble:</span>
                  <span className="text-slate-200">LSTM + XGBoost + FinBERT</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Vector Storage:</span>
                  <span className="text-cyan-400">ChromaDB RAG Retrieval</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">State Storage:</span>
                  <span className="text-slate-200">Firebase Firestore</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">User Interface:</span>
                  <span className="text-slate-200">React + Vite (15+ Dashboards)</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Pure Python Rewrite:</span>
                  <span className="text-emerald-400 font-semibold">Framework-Free Agent Loop</span>
                </div>
              </div>
            </div>

            {/* Documentation & Diary Callout */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/30 border border-emerald-500/30 rounded-2xl p-5 space-y-3">
              <div className="flex items-center gap-2 font-heading font-semibold text-sm text-emerald-400">
                <BookOpen className="w-4 h-4 text-emerald-400" />
                <span>Exhaustively Documented Architecture</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                Includes an 83-page engineering report detailing mathematical formulas for the risk engine, FinBERT sentiment scoring functions, and an active project diary tracing iterative deployment milestones.
              </p>
              <button
                onClick={onOpenReportModal}
                className="w-full flex items-center justify-center gap-2 py-2 text-xs font-mono font-medium text-emerald-300 bg-emerald-900/40 hover:bg-emerald-900/60 border border-emerald-500/30 rounded-lg transition-colors"
              >
                <span>View Report Chapter Index & Excerpts</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right Live Interactive Simulator (7 cols) */}
          <div className="lg:col-span-7">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 backdrop-blur-xl shadow-2xl relative">
              {/* Simulator Header & Controls */}
              <div className="flex flex-wrap items-center justify-between pb-4 mb-5 border-b border-slate-800 gap-3">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span className="font-heading font-bold text-white text-base">
                    Interactive Multi-Agent Evaluation Simulator
                  </span>
                </div>

                {/* Framework Toggle */}
                <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-[11px] font-mono">
                  <button
                    onClick={() => setFrameworkMode('langgraph')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      frameworkMode === 'langgraph'
                        ? 'bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    LangGraph
                  </button>
                  <button
                    onClick={() => setFrameworkMode('pure-python')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      frameworkMode === 'pure-python'
                        ? 'bg-cyan-500/20 text-cyan-400 font-semibold border border-cyan-500/30'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Pure Python Rewrite
                  </button>
                </div>
              </div>

              {/* Ticker Selector Presets */}
              <div className="mb-5 space-y-2">
                <span className="text-xs font-mono text-slate-400 block">
                  Select NSE Equity Ticker for Evaluation:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {tickerPresets.map((t) => (
                    <button
                      key={t.symbol}
                      onClick={() => {
                        setSelectedTicker(t.symbol);
                        setActiveStep(-1);
                      }}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer font-mono text-xs ${
                        selectedTicker === t.symbol
                          ? 'bg-emerald-950/60 border-emerald-500 text-white shadow-md shadow-emerald-500/10'
                          : 'bg-slate-950/50 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                      }`}
                    >
                      <div className="font-bold flex items-center justify-between">
                        <span>{t.symbol.replace('.NS', '')}</span>
                        <span className={t.change.startsWith('+') ? 'text-emerald-400 text-[10px]' : 'text-red-400 text-[10px]'}>
                          {t.change}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500 truncate">{t.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Run Trigger Button */}
              <div className="mb-6 flex items-center gap-3">
                <button
                  onClick={runSimulator}
                  disabled={isRunning}
                  className={`flex-1 py-3 px-4 rounded-xl font-mono text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg ${
                    isRunning
                      ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
                      : 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 shadow-emerald-500/20'
                  }`}
                >
                  {isRunning ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-400" />
                      <span>Executing Agent Graph Pipeline ({activeStep + 1}/{agentSteps.length})...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-current" />
                      <span>Execute Multi-Agent Evaluation on {selectedTicker}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Step-by-Step Agent Execution Pipeline Display */}
              <div className="space-y-2 bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs max-h-80 overflow-y-auto">
                {agentSteps.map((agent, index) => {
                  const isCurrent = activeStep === index;
                  const isDone = activeStep > index;

                  return (
                    <div
                      key={agent.id}
                      className={`p-3 rounded-lg border transition-all ${
                        isCurrent
                          ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200 shadow-md shadow-emerald-500/10'
                          : isDone
                          ? 'bg-slate-900/60 border-slate-800 text-slate-300'
                          : 'bg-slate-900/20 border-slate-800/40 text-slate-500 opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                              isCurrent
                                ? 'bg-emerald-400 text-slate-950 animate-bounce'
                                : isDone
                                ? 'bg-emerald-900 text-emerald-300 border border-emerald-500/40'
                                : 'bg-slate-800 text-slate-500'
                            }`}
                          >
                            {index + 1}
                          </div>
                          <span className="font-bold text-white">{agent.name}</span>
                          <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                            {agent.model}
                          </span>
                        </div>

                        {isDone && <span className="text-[10px] text-emerald-400 font-semibold">✓ Completed</span>}
                        {isCurrent && <span className="text-[10px] text-emerald-300 animate-pulse">Running...</span>}
                      </div>

                      <div className="text-[11px] text-slate-400 mt-1 pl-7">
                        {agent.description}
                      </div>

                      {(isCurrent || isDone) && (
                        <div className="mt-2 pt-2 border-t border-slate-800/60 pl-7 text-[10px] space-y-0.5 text-slate-300">
                          <div>
                            <span className="text-slate-500">Output: </span>
                            <span className="text-emerald-300">{agent.output}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Consensus Signal Result Panel (Active when finished or step 6) */}
              {activeStep >= 6 && (
                <div className="mt-4 p-4 rounded-xl bg-gradient-to-br from-emerald-950/90 to-slate-900 border border-emerald-500/50 shadow-xl space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-slate-300 uppercase tracking-wider">
                      Synthesized Market Consensus
                    </span>
                    <span className="px-2.5 py-0.5 text-[10px] font-mono text-emerald-400 bg-emerald-950 border border-emerald-500/40 rounded">
                      VERIFIED CONSENSUS
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-heading font-extrabold text-emerald-400 flex items-center gap-2">
                        BUY RECOMMENDATION
                        <span className="text-sm font-mono font-normal text-slate-300">(88.4% Confidence)</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 font-sans">
                        Technical momentum bullish + FinBERT sentiment score +0.74 (Positive) + PyTorch LSTM 5-day horizon trajectory targets +2.4% upside with strict stop-loss set by Risk Guard Agent.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* 15+ Dashboards Feature Strip */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
          <h3 className="font-heading font-bold text-white text-lg mb-4 flex items-center gap-2">
            <LineChart className="w-5 h-5 text-emerald-400" />
            <span>15+ Production Dashboards Built in React + Vite</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs text-slate-300">
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="block font-bold text-emerald-400 mb-0.5">01. Signal Hub</span>
              <span className="text-[10px] text-slate-400">Consensus Feed</span>
            </div>
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="block font-bold text-cyan-400 mb-0.5">02. FinBERT Heatmap</span>
              <span className="text-[10px] text-slate-400">NLP News Polarity</span>
            </div>
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="block font-bold text-indigo-400 mb-0.5">03. LSTM Trajectory</span>
              <span className="text-[10px] text-slate-400">5-Day Price Curves</span>
            </div>
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="block font-bold text-amber-400 mb-0.5">04. Risk & VaR</span>
              <span className="text-[10px] text-slate-400">Value at Risk Engine</span>
            </div>
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="block font-bold text-emerald-400 mb-0.5">05. RAG Vector Docs</span>
              <span className="text-[10px] text-slate-400">ChromaDB Filings</span>
            </div>
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center">
              <span className="block font-bold text-purple-400 mb-0.5">06. n8n Workflows</span>
              <span className="text-[10px] text-slate-400">Pipeline Triggers</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
