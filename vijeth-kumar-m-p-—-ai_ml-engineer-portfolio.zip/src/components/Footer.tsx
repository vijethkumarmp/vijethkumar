import React from 'react';
import { PERSONAL_INFO, LANGUAGES } from '../data/portfolioData';
import { Globe2, MapPin, Mail, Phone, Linkedin, ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050810] border-t border-slate-800/80 py-12 text-slate-400 font-mono text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-8 border-b border-slate-800/80">
          {/* Identity */}
          <div>
            <div className="flex items-center gap-2 text-white font-heading font-bold text-lg mb-1">
              <span>Vijeth Kumar M P</span>
            </div>
            <p className="text-slate-400 text-xs font-sans max-w-md">
              AI/ML Engineer specializing in autonomous agentic systems, financial intelligence (NSE), and full-stack platforms.
            </p>
          </div>

          {/* Social / Contact Links */}
          <div className="flex flex-wrap items-center gap-4">
            <a
              href={`mailto:${PERSONAL_INFO.email}`}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-emerald-400 transition-colors flex items-center gap-1.5"
            >
              <Mail className="w-3.5 h-3.5 text-emerald-400" />
              <span>Email</span>
            </a>

            <a
              href={`tel:${PERSONAL_INFO.phone}`}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-400 transition-colors flex items-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-cyan-400" />
              <span>Call</span>
            </a>

            <a
              href={PERSONAL_INFO.linkedin}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-purple-400 transition-colors flex items-center gap-1.5"
            >
              <Linkedin className="w-3.5 h-3.5 text-purple-400" />
              <span>LinkedIn</span>
            </a>

            <button
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-400 transition-colors cursor-pointer"
              title="Scroll to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Middle Languages Spoken Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 text-slate-400 text-[11px]">
          <div className="flex items-center gap-2">
            <Globe2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Spoken Languages:</span>
            <span className="text-slate-300 font-semibold">English (Fluent) • Kannada (Fluent) • Hindi (Fluent) • Tamil (Understands) • Telugu (Understands)</span>
          </div>

          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            <span>Bengaluru, Karnataka, India</span>
          </div>
        </div>

        {/* Bottom Credits */}
        <div className="pt-4 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-slate-500">
          <div>
            © {new Date().getFullYear()} Vijeth Kumar M P. All Rights Reserved.
          </div>
          <div className="text-emerald-400/80">
            Engineered for Reproducible Zero-Cost Cloud Architecture
          </div>
        </div>
      </div>
    </footer>
  );
};
