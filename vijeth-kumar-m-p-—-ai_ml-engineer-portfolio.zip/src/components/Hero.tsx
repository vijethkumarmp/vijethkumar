import React, { useEffect, useRef } from 'react';
import { Bot, ArrowRight, FileText, Sparkles, Cpu, Layers, CheckCircle2, ShieldCheck, Database } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface HeroProps {
  onOpenResume: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenResume }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Background Canvas: Subtle Candlestick & Agent Graph Matrix
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };

    window.addEventListener('resize', handleResize);

    // Agent Nodes
    const nodes = [
      { x: width * 0.15, y: height * 0.25, label: 'Data Agent', color: '#10b981' },
      { x: width * 0.35, y: height * 0.18, label: 'Tech Analysis', color: '#06b6d4' },
      { x: width * 0.55, y: height * 0.3, label: 'FinBERT NLP', color: '#8b5cf6' },
      { x: width * 0.75, y: height * 0.2, label: 'LSTM Forecast', color: '#3b82f6' },
      { x: width * 0.85, y: height * 0.5, label: 'XGBoost Feature', color: '#f59e0b' },
      { x: width * 0.65, y: height * 0.75, label: 'Risk Guard', color: '#ef4444' },
      { x: width * 0.3, y: height * 0.7, label: 'Consensus Agent', color: '#10b981' },
    ];

    // Simulated Stock Candlesticks
    const candles = Array.from({ length: 28 }, (_, i) => ({
      x: (width / 28) * i + 10,
      open: 100 + Math.random() * 40,
      close: 100 + Math.random() * 40,
      high: 150 + Math.random() * 20,
      low: 80 + Math.random() * 20,
    }));

    let step = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw subtle grid lines
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.25)';
      ctx.lineWidth = 1;

      for (let x = 0; x < width; x += 60) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 60) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw Candlesticks in low opacity
      candles.forEach((c, idx) => {
        const isUp = c.close >= c.open;
        ctx.strokeStyle = isUp ? 'rgba(16, 185, 129, 0.12)' : 'rgba(239, 68, 68, 0.12)';
        ctx.fillStyle = isUp ? 'rgba(16, 185, 129, 0.18)' : 'rgba(239, 68, 68, 0.18)';

        ctx.beginPath();
        ctx.moveTo(c.x, c.low);
        ctx.lineTo(c.x, c.high);
        ctx.stroke();

        const top = Math.min(c.open, c.close);
        const heightCandle = Math.max(Math.abs(c.close - c.open), 4);
        ctx.fillRect(c.x - 4, top, 8, heightCandle);
      });

      // Draw connecting edges between Agent nodes
      step += 0.015;
      nodes.forEach((n1, i) => {
        nodes.forEach((n2, j) => {
          if (i < j) {
            ctx.strokeStyle = 'rgba(51, 65, 85, 0.3)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(n1.x, n1.y);
            ctx.lineTo(n2.x, n2.y);
            ctx.stroke();

            // Animated pulse along line
            const pulse = (Math.sin(step + i + j) + 1) / 2;
            const px = n1.x + (n2.x - n1.x) * pulse;
            const py = n1.y + (n2.y - n1.y) * pulse;

            ctx.fillStyle = n1.color;
            ctx.beginPath();
            ctx.arc(px, py, 2.5, 0, Math.PI * 2);
            ctx.fill();
          }
        });
      });

      // Draw Agent Nodes
      nodes.forEach((node) => {
        ctx.fillStyle = node.color;
        ctx.beginPath();
        ctx.arc(node.x, node.y, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = 'rgba(226, 232, 240, 0.4)';
        ctx.font = '10px JetBrains Mono';
        ctx.fillText(node.label, node.x + 8, node.y + 3);
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <section className="relative min-h-[92vh] pt-28 pb-16 flex flex-col justify-center overflow-hidden border-b border-slate-800/60">
      {/* Background Interactive Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none opacity-80 z-0"
      />

      {/* Radial Gradient Glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Top Status & Role Pill */}
        <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/70 text-xs font-mono text-slate-300 mb-6 backdrop-blur-md shadow-lg">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-emerald-400 font-semibold">FINAL-YEAR AI & DATA SCIENCE (BE)</span>
          <span className="text-slate-600">•</span>
          <span className="text-slate-300">Bengaluru, India</span>
        </div>

        <div className="max-w-3xl space-y-6">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-extrabold text-white tracking-tight leading-[1.1]">
            Engineered for <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
              Autonomous AI Systems
            </span>{' '}
            & End-to-End Production
          </h1>

          <p className="text-base sm:text-lg text-slate-300 font-sans leading-relaxed font-normal">
            An AI/ML engineer-in-training who independently conceptualizes and ships full agentic AI systems end-to-end — not just notebooks, but production-shaped platforms with real architecture, multi-agent pipelines, and deployable UIs — while deliberately designing for free-tier, resource-efficient infrastructure so the work is reproducible without enterprise budgets.
          </p>

          {/* CTA Buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-4">
            <a
              href="#projects"
              className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-slate-950 bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 rounded-xl shadow-lg shadow-emerald-500/20 transition-all transform hover:-translate-y-0.5 cursor-pointer font-sans"
            >
              <span>Explore Featured Projects</span>
              <ArrowRight className="w-4 h-4" />
            </a>

            <button
              onClick={onOpenResume}
              className="inline-flex items-center gap-2 px-5 py-3.5 text-sm font-medium text-slate-300 hover:text-white bg-slate-900/60 hover:bg-slate-800/80 border border-slate-700/80 rounded-xl transition-all cursor-pointer backdrop-blur-md"
            >
              <FileText className="w-4 h-4 text-slate-400" />
              <span>Download Résumé</span>
            </button>
          </div>

          {/* Technical Highlights Badges */}
          <div className="pt-4 flex flex-wrap items-center gap-y-2 gap-x-3 text-xs font-mono text-slate-400">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Zero Enterprise Budget Reliance</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <Database className="w-4 h-4 text-cyan-400" />
              <span>ChromaDB Vector RAG + Firebase</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <Cpu className="w-4 h-4 text-teal-400" />
              <span>Pure Python & LangGraph Orchestration</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
