import React from 'react';
import { Project } from '../types';
import { ArrowRight, Layers, Bot, Layout, ShieldCheck, CheckCircle2, Sparkles, FileText, Cpu, ExternalLink } from 'lucide-react';

interface ProjectCardProps {
  project: Project;
  onOpenCaseStudy: (projectId: string) => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, onOpenCaseStudy }) => {
  const getStatusBadgeClass = (statusColor?: string) => {
    switch (statusColor) {
      case 'emerald':
        return 'bg-emerald-950/80 text-emerald-400 border-emerald-500/40';
      case 'cyan':
        return 'bg-cyan-950/80 text-cyan-400 border-cyan-500/40';
      case 'purple':
        return 'bg-purple-950/80 text-purple-400 border-purple-500/40';
      case 'amber':
        return 'bg-amber-950/80 text-amber-400 border-amber-500/40';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 group hover:shadow-xl hover:shadow-emerald-500/5 backdrop-blur-md">
      <div>
        {/* Top Badges */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-md text-[11px] font-mono font-medium bg-slate-800 text-slate-300 border border-slate-700">
              {project.domain}
            </span>
            <span className="px-2.5 py-1 rounded-md text-[11px] font-mono font-medium bg-emerald-950/40 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
              <Bot className="w-3 h-3" />
              {project.stackType}
            </span>
          </div>

          <span
            className={`px-2.5 py-1 rounded-md text-[10px] font-mono font-semibold border ${getStatusBadgeClass(
              project.statusColor
            )}`}
          >
            {project.status}
          </span>
        </div>

        {/* Title & Tagline */}
        <h3 className="text-xl font-heading font-bold text-white group-hover:text-emerald-400 transition-colors mb-1">
          {project.title}
        </h3>
        <p className="text-xs font-mono text-slate-400 mb-3">{project.subtitle}</p>

        <p className="text-sm text-slate-300 font-sans leading-relaxed mb-4 line-clamp-3">
          {project.description}
        </p>

        {/* Dual Artifact Highlight for TaxNexus AI */}
        {project.hasDualArtifacts && project.dualArtifactDetails && (
          <div className="mb-4 p-3 rounded-xl bg-purple-950/30 border border-purple-500/30 text-xs text-purple-200 font-mono space-y-1">
            <div className="font-semibold text-purple-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              Dual Visual Artifacts Included:
            </div>
            <div className="text-[11px] text-slate-300 pl-4">
              • {project.dualArtifactDetails.dashboardTitle}
            </div>
            <div className="text-[11px] text-slate-300 pl-4">
              • {project.dualArtifactDetails.landingTitle}
            </div>
          </div>
        )}

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          {project.metrics.map((m, idx) => (
            <div key={idx} className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
              <span className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                {m.label}
              </span>
              <span className="text-sm font-heading font-bold text-slate-200">{m.value}</span>
            </div>
          ))}
        </div>

        {/* Tech Tag List */}
        <div className="flex flex-wrap gap-1.5 mb-6">
          {project.techStackList.map((tech) => (
            <span
              key={tech}
              className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-950 text-slate-400 border border-slate-800/80"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>

      {/* Card Footer Actions */}
      <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
        {project.docReport ? (
          <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
            <FileText className="w-3.5 h-3.5" />
            {project.docReport.pages}-Page Technical Report
          </span>
        ) : (
          <span className="text-[11px] font-mono text-slate-400">Detailed Case Study</span>
        )}

        <button
          onClick={() => onOpenCaseStudy(project.id)}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-all cursor-pointer font-sans"
        >
          <span>View Case Study</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
