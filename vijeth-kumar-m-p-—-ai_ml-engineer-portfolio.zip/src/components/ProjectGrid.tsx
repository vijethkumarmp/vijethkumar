import React, { useState } from 'react';
import { PROJECTS } from '../data/portfolioData';
import { ProjectCard } from './ProjectCard';
import { DomainFilter, StackFilter } from '../types';
import { Layers, Filter, Bot, Code2, Sparkles } from 'lucide-react';

interface ProjectGridProps {
  onOpenCaseStudy: (projectId: string) => void;
}

export const ProjectGrid: React.FC<ProjectGridProps> = ({ onOpenCaseStudy }) => {
  const [domainFilter, setDomainFilter] = useState<DomainFilter>('All');
  const [stackFilter, setStackFilter] = useState<StackFilter>('All');

  const domainOptions: DomainFilter[] = ['All', 'Fintech', 'GovTech', 'Travel', 'EdTech/Coursework'];
  const stackOptions: StackFilter[] = ['All', 'Agentic AI', 'Full-Stack', 'ML'];

  const filteredProjects = PROJECTS.filter((project) => {
    const matchesDomain = domainFilter === 'All' || project.domain === domainFilter;
    const matchesStack = stackFilter === 'All' || project.stackType === stackFilter;
    return matchesDomain && matchesStack;
  });

  return (
    <section id="projects" className="py-20 border-b border-slate-800 bg-[#090d16] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 font-mono text-xs font-semibold mb-3">
              <Layers className="w-3.5 h-3.5" />
              <span>COMPLETE PROJECT PORTFOLIO</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-white tracking-tight">
              All Engineered Systems
            </h2>
            <p className="text-slate-400 font-mono text-xs sm:text-sm mt-1">
              End-to-end agentic platforms, civic governance suites, and financial analysis engines.
            </p>
          </div>

          <div className="text-xs font-mono text-slate-400 bg-slate-900/80 px-3 py-1.5 rounded-lg border border-slate-800">
            Showing <span className="text-emerald-400 font-bold">{filteredProjects.length}</span> of {PROJECTS.length} Systems
          </div>
        </div>

        {/* Filter Controls */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 mb-8 space-y-4 backdrop-blur-md">
          {/* Domain Filter Chips */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-mono text-slate-400 mr-2 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-slate-400" /> Domain:
            </span>
            {domainOptions.map((domain) => (
              <button
                key={domain}
                onClick={() => setDomainFilter(domain)}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all cursor-pointer ${
                  domainFilter === domain
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                    : 'bg-slate-950/60 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {domain}
              </button>
            ))}
          </div>

          {/* Stack Filter Chips */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/60">
            <span className="text-xs font-mono text-slate-400 mr-2 flex items-center gap-1">
              <Code2 className="w-3.5 h-3.5 text-slate-400" /> Stack Type:
            </span>
            {stackOptions.map((stack) => (
              <button
                key={stack}
                onClick={() => setStackFilter(stack)}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all cursor-pointer ${
                  stackFilter === stack
                    ? 'bg-cyan-400 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                    : 'bg-slate-950/60 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {stack}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        {filteredProjects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <ProjectCard key={project.id} project={project} onOpenCaseStudy={onOpenCaseStudy} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-slate-900/50 rounded-2xl border border-slate-800 text-slate-400 font-mono text-sm">
            No projects match the selected domain and stack filters.
            <button
              onClick={() => {
                setDomainFilter('All');
                setStackFilter('All');
              }}
              className="block mx-auto mt-3 px-4 py-2 text-xs text-emerald-400 underline cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
