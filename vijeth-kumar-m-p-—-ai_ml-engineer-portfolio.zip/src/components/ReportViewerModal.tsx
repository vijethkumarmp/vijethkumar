import React, { useState } from 'react';
import { X, BookOpen, FileText, CheckCircle2, ChevronRight, Download, Sparkles, ShieldCheck, Terminal } from 'lucide-react';

interface ReportViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReportViewerModal: React.FC<ReportViewerModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [activeChapter, setActiveChapter] = useState<number>(1);

  const chapters = [
    {
      num: 1,
      title: 'Introduction & NSE Market Intelligence Requirements',
      pages: 'Pages 1 – 12',
      summary:
        'Formal problem formulation addressing information asymmetry in Indian equity trading. Defines the latency, OHLCV data structures, and news sentiment requirements for retail decision support.'
    },
    {
      num: 2,
      title: 'LangGraph Multi-Agent Architecture & Consensus Engine',
      pages: 'Pages 13 – 28',
      summary:
        'Mathematical specification of state transitions across Data Ingestion, Technical Analysis, FinBERT, LSTM, XGBoost, Risk Guard, and Signal Synthesizer agents. Includes cyclic state graph execution flows.'
    },
    {
      num: 3,
      title: 'Neural Ensemble Design (LSTM + XGBoost + FinBERT)',
      pages: 'Pages 29 – 45',
      summary:
        'Loss function derivations for sequence forecasting in PyTorch LSTM, feature importance matrix for XGBoost regressors, and fine-tuning parameters for FinBERT financial sentiment transformer models.'
    },
    {
      num: 4,
      title: 'ChromaDB Vector Store & RAG Retrieval Pipelines',
      pages: 'Pages 46 – 58',
      summary:
        'Embedding generation, HNSW index configuration, document chunking strategies for quarterly earnings reports and live NSE exchange press releases.'
    },
    {
      num: 5,
      title: 'Firebase Persistence & 15+ React Dashboard Layouts',
      pages: 'Pages 59 – 70',
      summary:
        'Real-time Firestore sync schemas, state management patterns in React + Vite, and UX component design for risk metrics, portfolio stress tests, and signal feeds.'
    },
    {
      num: 6,
      title: 'n8n Automation & Framework-Free Pure-Python Rewrite',
      pages: 'Pages 71 – 78',
      summary:
        'Webhook triggers, scheduled pipeline orchestration in n8n, and full code walk-through of the pure Python orchestrator rewrite operating without third-party agent framework abstractions.'
    },
    {
      num: 7,
      title: 'Ongoing Project Diary & Live Deployment Milestones',
      pages: 'Pages 79 – 83',
      summary:
        'Iterative development journal tracking latency optimization, zero-cost cloud deployment setup on Cloud Run / Vercel, and empirical validation logs.'
    }
  ];

  const diaryEntries = [
    {
      date: 'Milestone Day 14',
      title: 'LangGraph State Cycle Optimization',
      log: 'Resolved state race condition between FinBERT sentiment classification and XGBoost probability distribution. Established synchronous checkpoint barrier before Signal Synthesizer invocation.'
    },
    {
      date: 'Milestone Day 28',
      title: 'Pure-Python Framework-Free Orchestrator',
      log: 'Completed 100% framework-free agent loop rewrite in standard Python `asyncio`. Verified zero degradation in signal consensus time compared to LangGraph runtime.'
    },
    {
      date: 'Milestone Day 42',
      title: 'ChromaDB RAG Embedding Persistence',
      log: 'Integrated local ChromaDB vector store with cosine similarity index. Verified sub-50ms context retrieval for quarterly SEBI disclosure filings.'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-4xl bg-[#0d1322] border border-emerald-500/30 rounded-2xl shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 bg-slate-900/90 flex items-start justify-between">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-400 font-mono text-xs font-semibold mb-2">
              <BookOpen className="w-3.5 h-3.5" />
              <span>OFFICIAL 83-PAGE TECHNICAL REPORT & SYSTEM DIARY</span>
            </div>
            <h2 className="text-2xl font-heading font-bold text-white">
              EquityMind AI System Architecture Report
            </h2>
            <p className="text-xs font-mono text-slate-400">
              Author: Vijeth Kumar M P • Don Bosco Institute of Technology, Bengaluru
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800/60 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close Report Viewer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-300 font-sans text-sm flex-1">
          {/* Executive Overview */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <h3 className="font-heading font-bold text-base text-white flex items-center justify-between">
              <span>Executive Summary</span>
              <span className="text-xs font-mono text-emerald-400">83 Pages Total</span>
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
              This 83-page engineering document serves as the complete technical blueprint for EquityMind AI. It covers mathematical proofs, neural model parameters, LangGraph cyclic state machines, RAG embedding strategies, and an ongoing project development diary documenting zero-cost cloud deployment paradigms.
            </p>
          </div>

          {/* Chapter Index */}
          <div className="space-y-3">
            <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>Report Chapter Index</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {/* Left Chapter Buttons (5 cols) */}
              <div className="md:col-span-5 space-y-2">
                {chapters.map((chap) => (
                  <button
                    key={chap.num}
                    onClick={() => setActiveChapter(chap.num)}
                    className={`w-full p-3 rounded-xl border text-left font-mono text-xs transition-all cursor-pointer flex items-center justify-between ${
                      activeChapter === chap.num
                        ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-lg shadow-emerald-500/10'
                        : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                    }`}
                  >
                    <div>
                      <span className="font-bold text-emerald-400 block">Ch. {chap.num}</span>
                      <span className="text-[11px] text-slate-300 truncate block max-w-[200px]">
                        {chap.title}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 shrink-0">{chap.pages}</span>
                  </button>
                ))}
              </div>

              {/* Right Chapter Active Detail (7 cols) */}
              <div className="md:col-span-7 bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
                {chapters
                  .filter((c) => c.num === activeChapter)
                  .map((chap) => (
                    <div key={chap.num} className="space-y-3">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                        <span className="font-mono text-xs font-bold text-emerald-400 uppercase">
                          Chapter {chap.num} Detail
                        </span>
                        <span className="font-mono text-xs text-slate-500">{chap.pages}</span>
                      </div>
                      <h4 className="font-heading font-bold text-base text-white">{chap.title}</h4>
                      <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
                        {chap.summary}
                      </p>
                      <div className="pt-3 border-t border-slate-800/80 flex items-center gap-2 text-xs font-mono text-slate-400">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>Included in full repository documentation</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          {/* Project Diary Excerpts */}
          <div className="space-y-3">
            <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>Project Diary Excerpts (Chapter 7)</span>
            </h3>

            <div className="space-y-3">
              {diaryEntries.map((entry, idx) => (
                <div key={idx} className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1 font-mono text-xs">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="text-emerald-400 font-bold">{entry.date}</span>
                    <span className="text-[10px] text-slate-500">{entry.title}</span>
                  </div>
                  <p className="text-slate-300 font-sans text-xs pt-1">{entry.log}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between font-mono text-xs">
          <span className="text-slate-400">83 Pages • Full Report On File</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            Close Report View
          </button>
        </div>
      </div>
    </div>
  );
};
