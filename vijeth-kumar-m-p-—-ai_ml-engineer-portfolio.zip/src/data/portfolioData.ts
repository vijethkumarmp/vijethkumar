import { Project, SkillCategory, EducationItem, LanguageItem } from '../types';

export const PERSONAL_INFO = {
  name: 'Vijeth Kumar M P',
  title: 'AI/ML Engineer & Agentic Systems Architect',
  location: 'Bengaluru, Karnataka, India',
  email: 'vijethkumar955@gmail.com',
  phone: '+91 7975605499',
  linkedin: 'https://linkedin.com/in/vijeth-kumar-',
  github: 'https://github.com',
  positioning:
    'An AI/ML engineer-in-training who independently conceptualizes and ships full agentic AI systems end-to-end — not just notebooks, but production-shaped platforms with real architecture, multi-agent pipelines, and deployable UIs — while deliberately designing for free-tier, resource-efficient infrastructure so the work is reproducible without enterprise budgets.',
  shortBio:
    'Based in Bengaluru, I specialize in building multi-agent AI pipelines, financial intelligence platforms, and full-stack governance tools. I engineer systems with autonomous multi-agent pipelines, hybrid neural-ensemble models, and vector RAG persistence — all optimized to run on resource-efficient, zero-cost cloud tiers.',
  keyStats: [
    { value: 'Multi-Agent', label: 'LangGraph Pipeline' },
    { value: '15+', label: 'Production AI Dashboards' },
    { value: '83', label: 'Page Technical Report' },
    { value: '8', label: 'GovTech Civic Modules' },
    { value: '100%', label: 'Free-Tier & Reproducible' },
  ]
};

export const PROJECTS: Project[] = [
  {
    id: 'equitymind-ai',
    title: 'EquityMind AI',
    subtitle: 'Real-Time Multi-Agent Equity Intelligence for NSE',
    domain: 'Fintech',
    stackType: 'Agentic AI',
    tagline: 'LangGraph Multi-Agent Orchestration & Neural Sentiment Ensemble for Indian Markets',
    description:
      'Real-time, agentic, RAG-powered equity intelligence platform engineered specifically for the National Stock Exchange of India (NSE). Converts raw OHLCV price data and live financial news into actionable BUY / SELL / HOLD signals with confidence scores to empower retail investor decision support.',
    problem:
      'Retail investors in Indian equities face extreme information asymmetry: raw price feeds, high-frequency market news, and quarterly reports require multi-disciplinary analysis that individual traders cannot execute in real time without institutional Bloomberg terminal budgets.',
    architecture:
      'LangGraph-orchestrated multi-agent pipeline combining technical time-series models with deep financial sentiment analysis and vector-backed RAG retrieval.',
    keyDecisions: [
      'Engineered an ensemble of LSTM (time-series price forecasting), XGBoost (structured feature modeling), and FinBERT (financial news sentiment) coupled with broader LLM reasoning.',
      'Constructed dual persistence using Firebase Firestore for state management and ChromaDB as a vector store for RAG document retrieval.',
      'Developed 15+ specialized dashboard views in React + Vite covering sentiment heatmaps, signal breakdown, risk metrics, and portfolio stress tests.',
      'Orchestrated automated data refresh jobs via n8n workflows.',
      'Built a secondary pure-Python framework-free orchestrator rewrite to demonstrate deep architectural understanding beyond third-party library dependencies.'
    ],
    metrics: [
      { label: 'Autonomous Agents', value: 'Multi-Agent' },
      { label: 'Dashboard Views', value: '15+ Views' },
      { label: 'Technical Report', value: '83 Pages' },
      { label: 'Market Scope', value: 'NSE Equities' }
    ],
    status: 'Flagship — Live Architecture',
    statusColor: 'emerald',
    featured: true,
    priorityOrder: 1,
    docReport: {
      pages: 83,
      title: 'EquityMind AI System Architecture & Engineering Report',
      hasDiary: true
    },
    candlestickPreview: true,
    techStackList: [
      'LangGraph',
      'Python',
      'FinBERT',
      'LSTM',
      'XGBoost',
      'ChromaDB',
      'Firebase',
      'React',
      'TypeScript',
      'Vite',
      'n8n'
    ],
    agents: [
      {
        id: 'agent-1',
        name: 'Data Ingestion Agent',
        role: 'OHLCV & Live News Fetcher',
        model: 'Python Async Engine',
        description: 'Streams live NSE price ticks, historical candles, and financial news feeds via resilient background pipelines.',
        input: 'NSE Stock Ticker (e.g., RELIANCE.NS, TATAMOTORS.NS)',
        output: 'Clean OHLCV Pandas DataFrame & Raw News Payload',
        status: 'idle'
      },
      {
        id: 'agent-2',
        name: 'Technical Analysis Agent',
        role: 'Quantitative Indicator Calculator',
        model: 'NumPy / TA-Lib Python',
        description: 'Calculates RSI, MACD, Bollinger Bands, EMA crossovers, and volume profile metrics.',
        input: 'OHLCV Data Array',
        output: 'Technical Signal Vector (Bullish/Bearish Divergence)',
        status: 'idle'
      },
      {
        id: 'agent-3',
        name: 'Sentiment & News Agent',
        role: 'Financial NLP Classifier',
        model: 'FinBERT Transformer Model',
        description: 'Analyzes live Indian market news, corporate announcements, and press releases for sentiment polarity.',
        input: 'Recent News Headlines & Text Streams',
        output: 'FinBERT Polarity Score (-1.0 to +1.0) & Keyword Drivers',
        status: 'idle'
      },
      {
        id: 'agent-4',
        name: 'LSTM Forecasting Agent',
        role: 'Sequence Price Predictor',
        model: 'PyTorch Multi-layer LSTM',
        description: 'Projects 5-day horizon price trajectories using sequential neural weights trained on historical NSE trend cycles.',
        input: '60-day Lookback Sequence',
        output: '5-Day Predicted Trend Curve + Variance Interval',
        status: 'idle'
      },
      {
        id: 'agent-5',
        name: 'XGBoost Feature Agent',
        role: 'Structured Gradient Booster',
        model: 'XGBoost Regressor',
        description: 'Evaluates macroeconomic variables, sectoral indices, and fundamentals to produce baseline probability distribution.',
        input: 'Market Feature Matrix',
        output: 'Probability Mass for Market Direction',
        status: 'idle'
      },
      {
        id: 'agent-6',
        name: 'Risk & Volatility Agent',
        role: 'Guardrail & Position Sizer',
        model: 'Quant Risk Engine',
        description: 'Computes Value-at-Risk (VaR), Sharpe ratio, beta relative to Nifty 50, and dynamic stop-loss recommendations.',
        input: 'Portfolio Weight & Volatility Metrics',
        output: 'Max Drawdown Alert & Position Sizing Limit',
        status: 'idle'
      },
      {
        id: 'agent-7',
        name: 'Signal Synthesizer Agent',
        role: 'Master Consensus & Report Generator',
        model: 'LangGraph Consensus Graph + LLM',
        description: 'Synthesizes weighted outputs from technical, sentiment, neural, and risk agents into a unified BUY/SELL/HOLD decision with confidence percentage.',
        input: 'Outputs from Agents 1–6 + ChromaDB RAG Context',
        output: 'Final Signal (e.g. BUY 88% Confidence) + Markdown Summary',
        status: 'idle'
      }
    ]
  },
  {
    id: 'gramamrit',
    title: 'GramAmrit',
    subtitle: '8-Module Civic Governance Platform for Rural Administration',
    domain: 'GovTech',
    stackType: 'Full-Stack',
    tagline: 'End-to-End Digitalization for Gram Panchayat Governance & Public Grievances',
    description:
      'A comprehensive 8-module rural governance platform engineered to digitize panchayat administrative workflows, public asset distribution, citizen grievance resolution, and local budget tracking across rural communities.',
    problem:
      'Rural governance in India suffers from fragmented physical record keeping, slow manual grievance workflows, and lack of transparent audit trails for public developmental grants at the Gram Panchayat level.',
    architecture:
      'Full-stack architecture built with TypeScript, React, Express, and MongoDB. Designed with a custom cohesive UI design system, RBAC (Role-Based Access Control) for local administrators vs citizens, and formal modular APIs.',
    keyDecisions: [
      'Engineered an 8-module workflow suite covering Grievance Redressal, Gram Sabha Notices, Public Asset Tracking, Scheme Eligibility Checker, Revenue Collection, Water & Sanitation Logs, Agriculture Updates, and Local Meeting Minutes.',
      'Established a rigorous UI Design System with high-contrast responsive components tailored for low-bandwidth rural connectivity.',
      'Authored comprehensive system architecture documentation detailing data models and state machines before writing code.'
    ],
    metrics: [
      { label: 'Core Modules', value: '8 Modules' },
      { label: 'Architecture Docs', value: 'Complete' },
      { label: 'Tech Stack', value: 'MERN + TS' },
      { label: 'Target Sector', value: 'GovTech' }
    ],
    status: 'Production System Built',
    statusColor: 'cyan',
    featured: true,
    priorityOrder: 2,
    techStackList: ['TypeScript', 'React', 'Express.js', 'MongoDB', 'Node.js', 'Tailwind CSS']
  },
  {
    id: 'taxnexus-ai',
    title: 'TaxNexus AI',
    subtitle: 'AI-Powered Tax Compliance & Advisory Intelligence Platform',
    domain: 'Fintech',
    stackType: 'Agentic AI',
    tagline: 'Dual-Artifact Architecture: Interactive SaaS Product UI & High-Conversion Go-To-Market Landing Page',
    description:
      'Tax-focused AI platform delivering automated tax code analysis, filing recommendations, deduction discovery, and document clause scanning for individuals and small businesses.',
    problem:
      'Constantly evolving tax regulations and complex tax codes create compliance anxiety and lost deductions for non-specialists who cannot afford dedicated tax consultants.',
    architecture:
      'Features a dual-artifact showcase: an interactive web application dashboard for active tax calculation and advisory, plus an independently designed marketing landing page highlighting value propositions.',
    keyDecisions: [
      'Built a dedicated RAG pipeline for tax code document retrieval to ground advice in exact regulatory clauses.',
      'Created distinct design languages for the product dashboard (dense data, dark utility) and the go-to-market site (conversion-oriented, high visual impact).'
    ],
    metrics: [
      { label: 'Visual Artifacts', value: '2 Artifacts' },
      { label: 'Core Focus', value: 'Tax AI RAG' },
      { label: 'Design Scope', value: 'Dashboard + Marketing' }
    ],
    status: 'Case Study & Product UI Complete',
    statusColor: 'purple',
    featured: true,
    priorityOrder: 3,
    hasDualArtifacts: true,
    dualArtifactDetails: {
      dashboardTitle: 'TaxNexus Operations & Advisory Dashboard',
      landingTitle: 'TaxNexus GTM Marketing Landing Experience'
    },
    techStackList: ['React', 'TypeScript', 'Tailwind CSS', 'RAG Pipeline', 'Express', 'LLM Integration']
  },
  {
    id: 'fundsage-ai',
    title: 'FundSage AI',
    subtitle: 'Mutual Fund Analytics & Agentic Portfolio Intelligence System',
    domain: 'Fintech',
    stackType: 'Agentic AI',
    tagline: 'Detailed System Architecture & ML Specification for Indian Mutual Funds',
    description:
      'Mutual-fund analysis system designed to evaluate risk-adjusted returns, overlap between fund holdings, expense ratio impacts, and agentic fund recommendation agents across Indian asset management companies (AMCs).',
    problem:
      'Retail investors frequently purchase multiple overlapping mutual funds with identical underlying equities, leading to hidden concentration risk and compounding expense ratio leaks.',
    architecture:
      'System design specification complete covering ML factor models, portfolio overlap matrix calculators, RAG agents for SID (Scheme Information Documents), and pipeline orchestration.',
    keyDecisions: [
      'Completed comprehensive system specification detailing data schemas, API contracts, vector indexing strategy, and agent orchestration graph before full buildout.',
      'Designed portfolio overlap detection matrix for top 500 Indian equity funds.'
    ],
    metrics: [
      { label: 'Development Phase', value: 'Spec Complete' },
      { label: 'Market Focus', value: 'Indian AMCs' },
      { label: 'Core Engine', value: 'RAG + ML Factor' }
    ],
    status: 'Architecture Complete — In Build',
    statusColor: 'amber',
    featured: false,
    priorityOrder: 4,
    techStackList: ['System Design', 'ML Pipelines', 'RAG Agents', 'Python', 'React', 'Financial Modeling']
  },
  {
    id: 'travel-companion',
    title: 'Travel Companion Application',
    subtitle: 'Mobile-Oriented Trip Planning & Itinerary Logistics App',
    domain: 'Travel',
    stackType: 'Full-Stack',
    tagline: 'Academic Mobile-First UI & Offline-Capable Trip Management',
    description:
      'A mobile-oriented travel application engineered for dynamic itinerary planning, expense tracking, weather integration, and trip data management.',
    problem:
      'Travelers struggle with scattered bookings, flight updates, and budget tracking across disjointed notes and messaging apps while on the move.',
    architecture:
      'Mobile-first responsive architecture prioritizing touch interaction, local offline storage sync, and visual itinerary cards.',
    keyDecisions: [
      'Designed responsive touch-optimized travel timeline controls and budget allocation visualizer.',
      'Implemented client-side persistence for seamless offline access to itinerary details during poor connectivity.'
    ],
    metrics: [
      { label: 'Type', value: 'Academic Project' },
      { label: 'Platform', value: 'Mobile First' },
      { label: 'Focus', value: 'UI/UX & Storage' }
    ],
    status: 'Academic Build Completed',
    statusColor: 'slate',
    featured: false,
    priorityOrder: 5,
    techStackList: ['React', 'JavaScript/TypeScript', 'Tailwind CSS', 'Local Storage Sync', 'REST APIs']
  }
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    id: 'agentic',
    category: 'AI / ML & Agentic Frameworks',
    iconName: 'Bot',
    skills: [
      { name: 'LangGraph & Multi-Agent Graphs', level: 92, badge: 'Core Flagship', highlight: 'Multi-agent stateful orchestration with cyclic graph execution' },
      { name: 'RAG & Vector Stores (ChromaDB)', level: 90, badge: 'Production', highlight: 'Document chunking, embedding retrieval, and context grounding' },
      { name: 'FinBERT & NLP Transformers', level: 88, badge: 'Financial NLP', highlight: 'Financial news sentiment classification & polarity scoring' },
      { name: 'LSTM & Time-Series Models', level: 85, badge: 'Deep Learning', highlight: 'Sequential neural forecasting for market price trends' },
      { name: 'XGBoost & Gradient Boosting', level: 86, badge: 'Structured ML', highlight: 'Feature engineering & multi-class probability estimation' },
      { name: 'HuggingFace & PyTorch', level: 82, badge: 'Model Ops', highlight: 'Model fine-tuning, inference pipeline setup' },
      { name: 'Framework-Free Agent Systems', level: 94, badge: 'Pure Python', highlight: 'Custom Python agent loops without library dependencies' }
    ]
  },
  {
    id: 'languages',
    category: 'Programming Languages',
    iconName: 'Code2',
    skills: [
      { name: 'Python 3.x', level: 95, badge: 'Expert', highlight: 'Async pipelines, NumPy/Pandas, PyTorch, LangChain/Graph' },
      { name: 'TypeScript', level: 90, badge: 'Advanced', highlight: 'Strict typing, full-stack React + Node architectures' },
      { name: 'JavaScript (ES6+)', level: 92, badge: 'Advanced', highlight: 'Async/await, DOM, event loops, Web APIs' },
      { name: 'SQL / PostgreSQL', level: 85, badge: 'Database', highlight: 'Relational queries, index optimization, schema design' },
      { name: 'C++', level: 75, badge: 'Academic', highlight: 'Data structures, memory management, algorithms' }
    ]
  },
  {
    id: 'backend',
    category: 'Backend & Data Infrastructure',
    iconName: 'Server',
    skills: [
      { name: 'Node.js & Express.js', level: 90, badge: 'Production', highlight: 'RESTful API routing, middleware, authentication' },
      { name: 'Firebase (Firestore & Auth)', level: 88, badge: 'Cloud DB', highlight: 'Real-time database sync, rules, zero-cost tiering' },
      { name: 'MongoDB & Mongoose', level: 85, badge: 'NoSQL', highlight: 'Document schemas, aggregation pipelines' },
      { name: 'FastAPI & REST APIs', level: 86, badge: 'Python API', highlight: 'Async endpoints, Pydantic validation, Swagger docs' },
      { name: 'Vector DBs (ChromaDB)', level: 88, badge: 'RAG Store', highlight: 'Similarity search, HNSW indexing, embedding persistence' }
    ]
  },
  {
    id: 'frontend',
    category: 'Frontend & UI Engineering',
    iconName: 'Layout',
    skills: [
      { name: 'React 18 / 19', level: 92, badge: 'Core Web', highlight: 'Custom hooks, state management, complex dashboards' },
      { name: 'Vite & Modern Tooling', level: 90, badge: 'Build Tool', highlight: 'Fast HMR, module bundling, optimization' },
      { name: 'Tailwind CSS v4', level: 94, badge: 'Styling', highlight: 'Utility-first dark/light UI design systems' },
      { name: 'Motion / Animation', level: 88, badge: 'Interactive', highlight: 'Fluid scroll reveals, layout animations, transitions' }
    ]
  },
  {
    id: 'automation',
    category: 'Automation, Workflows & Tools',
    iconName: 'Cpu',
    skills: [
      { name: 'n8n Workflow Automation', level: 90, badge: 'Orchestration', highlight: 'Automated data fetch, API webhooks, scheduled triggers' },
      { name: 'Git & GitHub', level: 92, badge: 'Version Control', highlight: 'Branching, PRs, versioning, documentation' },
      { name: 'Resource-Efficient Infra', level: 95, badge: 'Architecture', highlight: 'Designing robust systems running 100% on free-tier cloud' }
    ]
  }
];

export const EDUCATION_HISTORY: EducationItem[] = [
  {
    id: 'edu-1',
    institution: 'Don Bosco Institute of Technology, Bengaluru',
    degree: 'B.E. in Artificial Intelligence & Data Science (VTU, 2022 Scheme)',
    location: 'Bengaluru, Karnataka, India',
    period: '2023 – 2027 (Final Year)',
    score: 'CGPA 7.0 / 10.0',
    isCurrent: true,
    highlights: [
      'Focusing on autonomous multi-agent pipelines, machine learning, deep neural networks, and scalable data engineering.',
      'Lead student developer for EquityMind AI and GramAmrit platforms.',
      'Consistently applying free-tier, zero-cost cloud architecture paradigms for reproducible research.'
    ],
    coursework: [
      'Machine Learning',
      'Deep Learning & Neural Networks',
      'Data Structures & Algorithms',
      'Database Management Systems',
      'Operating Systems',
      'Natural Language Processing',
      'Cloud Infrastructure'
    ]
  },
  {
    id: 'edu-2',
    institution: 'Sheshadripuram PU College',
    degree: 'Pre-University Course (PUC — Science Stream)',
    location: 'Bengaluru, Karnataka, India',
    period: '2020 – 2022',
    score: '60%',
    highlights: [
      'Physics, Chemistry, Mathematics, and Computer Science foundation.',
      'Built early interest in algorithmic problem solving and programming.'
    ]
  },
  {
    id: 'edu-3',
    institution: 'Balavikas International School',
    degree: 'Secondary School Leaving Certificate (SSLC — Class X)',
    location: 'Bengaluru, Karnataka, India',
    period: '2019 – 2020',
    score: '80%',
    highlights: [
      'Strong academic foundation in Mathematics, Science, and Analytical Logic.'
    ]
  }
];

export const LANGUAGES: LanguageItem[] = [
  { name: 'English', proficiency: 'Fluent' },
  { name: 'Kannada', proficiency: 'Fluent', nativeName: 'ಕನ್ನಡ' },
  { name: 'Hindi', proficiency: 'Fluent', nativeName: 'हिंदी' },
  { name: 'Tamil', proficiency: 'Understands', nativeName: 'தமிழ்' },
  { name: 'Telugu', proficiency: 'Understands', nativeName: 'తెలుగు' }
];

export const RESUME_TEXT = `VIJETH KUMAR M P
Bengaluru, Karnataka, India | +91 7975605499 | vijethkumar955@gmail.com
LinkedIn: linkedin.com/in/vijeth-kumar-

================================================================================
POSITIONING & OBJECTIVE
================================================================================
AI/ML Engineer specializing in end-to-end agentic AI systems, financial neural intelligence (NSE markets), and full-stack governance platforms. Focused on building production-shaped, reproducible architectures using multi-agent LangGraph pipelines, RAG vector stores, and neural ensembles while optimizing for zero-cost, resource-efficient infrastructure.

================================================================================
EDUCATION
================================================================================
Don Bosco Institute of Technology, Bengaluru
B.E. in Artificial Intelligence & Data Science (VTU, 2022 Scheme)
Period: 2023 – 2027 (Currently in Final Year) | CGPA: 7.0 / 10.0

Sheshadripuram PU College, Bengaluru
Pre-University Course (PUC — Science Stream) | 2020 – 2022 | Score: 60%

Balavikas International School, Bengaluru
SSLC (Class X) | 2019 – 2020 | Score: 80%

================================================================================
FEATURED PROJECTS
================================================================================
1. EquityMind AI — Real-Time Agentic Equity Intelligence Platform for NSE
   - Orchestrated a multi-agent pipeline using LangGraph for multi-disciplinary market decision support.
   - Built a neural ensemble combining PyTorch LSTM (time-series forecasting), XGBoost (feature modeling), and FinBERT (financial news sentiment).
   - Designed dual persistence with Firebase Firestore and ChromaDB vector store for RAG document context.
   - Developed 15+ interactive dashboard views in React + Vite and automated workflows via n8n.
   - Authored an 83-page comprehensive technical engineering report and ongoing project diary.
   - Implemented a framework-free pure-Python orchestrator rewrite demonstrating deep core loop design.

2. GramAmrit — 8-Module Rural Governance & Civic Platform
   - Built an end-to-end MERN + TypeScript platform digitizing rural panchayat administrative workflows.
   - Implemented 8 modules for grievance redressal, public asset tracking, scheme eligibility, and budget logs.
   - Created a custom responsive UI design system tailored for low-bandwidth rural connectivity.

3. TaxNexus AI — AI Tax Compliance & Advisory Platform
   - Developed dual visual artifacts: a full SaaS operations dashboard and a go-to-market marketing landing page.
   - Implemented tax code clause retrieval via RAG pipelines to assist tax planning.

4. FundSage AI — Mutual Fund Analytics & Agentic Portfolio System
   - Completed detailed system architecture and ML factor specification for Indian AMC mutual funds.
   - Designed portfolio overlap matrix calculation algorithms to detect underlying asset duplication.

================================================================================
TECHNICAL SKILLS
================================================================================
- AI / ML & Agentic: LangGraph, FinBERT, PyTorch, LSTM, XGBoost, RAG, ChromaDB, HuggingFace
- Languages: Python 3.x, TypeScript, JavaScript, SQL, C++
- Backend & Data: Node.js, Express.js, Firebase (Firestore/Auth), MongoDB, FastAPI, REST APIs
- Frontend: React 18/19, Vite, Tailwind CSS v4, Motion, HTML5/CSS3
- Tools & Automation: n8n, Git, GitHub, Postman, Linux, Resource-Efficient Cloud Architecture

================================================================================
LANGUAGES
================================================================================
Fluent: English, Kannada, Hindi | Understands: Tamil, Telugu
`;
