export type DomainFilter = 'All' | 'Fintech' | 'GovTech' | 'Travel' | 'EdTech/Coursework';
export type StackFilter = 'All' | 'Agentic AI' | 'Full-Stack' | 'ML';

export interface AgentInfo {
  id: string;
  name: string;
  role: string;
  model: string;
  description: string;
  input: string;
  output: string;
  status: 'idle' | 'running' | 'completed';
  confidenceScore?: number;
}

export interface Project {
  id: string;
  title: string;
  subtitle: string;
  domain: 'Fintech' | 'GovTech' | 'Travel' | 'EdTech/Coursework';
  stackType: 'Agentic AI' | 'Full-Stack' | 'ML';
  tagline: string;
  description: string;
  problem: string;
  architecture: string;
  keyDecisions: string[];
  metrics: { label: string; value: string }[];
  status: string; // e.g. "Production Ready", "System Design Complete — In Build", "Completed", "Academic Build"
  statusColor?: string;
  links?: { label: string; url: string; icon?: string }[];
  repoUrl?: string;
  featured: boolean;
  priorityOrder: number;
  docReport?: {
    pages?: number;
    title: string;
    hasDiary: boolean;
  };
  agents?: AgentInfo[];
  techStackList: string[];
  hasDualArtifacts?: boolean; // For TaxNexus AI
  dualArtifactDetails?: {
    dashboardTitle: string;
    landingTitle: string;
  };
  candlestickPreview?: boolean; // For EquityMind AI visual chart
}

export interface SkillItem {
  name: string;
  level: number; // 1-100
  badge?: string; // e.g. "Core", "Advanced", "In Production"
  highlight: string;
}

export interface SkillCategory {
  id: string;
  category: string;
  iconName: string;
  skills: SkillItem[];
}

export interface EducationItem {
  id: string;
  institution: string;
  degree: string;
  location: string;
  period: string;
  score: string;
  isCurrent?: boolean;
  highlights: string[];
  coursework?: string[];
}

export interface LanguageItem {
  name: string;
  proficiency: 'Fluent' | 'Understands';
  nativeName?: string;
}
